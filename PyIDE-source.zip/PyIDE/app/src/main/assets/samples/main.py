print("Hello from Android!")
